# COMP2123 Review Notes

Important: ADT, Time Complexity, Space Complexity, Correctness

Correctness: 

- data structures → invariant (the invariant holds before an
    
    operation is executed, the operation has the desired result 
    
    and the invariant still holds after the operation is executed)
    
- greedy → exchange argument (see 9-Greedy)
- divide and conquer → induction (recursion)

# 1 - Time Complexity Analysis

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image.png)

# 2 - Lists

| Data Structure | Operation | Time |
| --- | --- | --- |
| **Array** | `get(i)`, `set(i, e)` | O(1) |
|  | `insert(0, e)`, `remove(0)` from the start | O(n) |
|  | `insert(i, e)`, `remove(i)` in the middle | O(n) |
|  | `append(e)`, `pop()`               from the end | O(1) |
|  | `replace(i, e)`，`size()`，`isEmpty()` | O(1) |
| **Singly Linked** | `get(i)` | O(n) |
| / **Doubly Linked**  | `addFirst(e)`, `removeFirst()` from  start | O(1) |
|  | `add(i, e)`, `remove(i)`             in middle | O(n) |
|  | `addLast(e)`, `removeLast()`     from end | O(n) / O(1) |
|  | `replace(i, e)` | O(n) |
|  | `size()` | O(n) |
| **Stack**  | push(e), pop() | O(1) |
| **Queue** | enqueue(e), dequeue() | O(1) |

# 3 - Trees

### Tree ADT

| **Method** | **Time** |
| --- | --- |
| `size()`, `isEmpty()` | O(1) |
| `root()`, `parent(p` | O(1) |
| `children(p)` | O(c) |
| `numChildren(p)` | O(1) |
| `isInternal(p)`, `isExternal(p)`, `isRoot(p)` | O(1) |
- Tree Traversals: Preorder, Inorder, Postorder → O(n)

# 4 - Binary Search Trees

### Binary Search Tree (BST)

1. **Properties**:
    - For any node v, keys in the left subtree are less than v, and
        
        keys in the right subtree are greater than v.
        
    - In-order traversal of a BST results in keys in increasing order.
2. **Operations**:
    - **Search**: `search(k, v)` O(h) (h = height)
    - **Insertion**: `put(k, o)`  O(h)
        - If the key exists, replace the value.
        - Otherwise, insert at the reached external node.
    - **Deletion**: `remove(k)`  O(h)
        - **Case 1**: Node has one external child — remove and
            
                          promote the other child.
            
        - **Case 2**: Node has two internal children — find the
            
                            in-order successor, copy its value, and delete it.
            
3. **Complexity**:
    - **Space**: O(n)
    - **Best Case Height**: O(log n)
    - **Worst Case Height**: O(n)

---

### Range Queries in BST

- **Purpose**: Find all keys k in range k1≤k≤k2.
- **Algorithm**: in-order (ascending order)
    - Traverse left or right subtree based on key comparisons.
    - |inside nodes| ≤ |output|; |boundary node| ≤ 2 * tree height
    - **Time Complexity**: O(|output| + logn)

---

### AVL Tree (Self-Balancing BST)

nodes usually contains a key/a pointer

1. **Properties**:
    - Balanced BST where the heights of left and right subtrees of
        
        every node differ by at most 1.
        
    - **Height**: O(log n)
2. **Operations**:
    - **Search:**
        - **Time Complexity**: O(log n)
    - **Insertion**:
        - Standard BST insertion, followed by rebalancing.
        - If balance property is violated, perform rotations
        - **Time Complexity**: O(log n)
    - **Deletion**:
        - Standard BST deletion, followed by rebalancing using
            
            rotations if necessary.
            
        - **Time Complexity**: O(log n)
3. **Trinode Restructuring**:
    - Helps restore balance by making the middle node of three
        
        unbalanced nodes the root of that subtree.
        
    - **Time Complexity**: O(1) for rotation operations.

---

### Map ADT (Key-Value Store)

| **Method** | **Description** |
| --- | --- |
| `size()` | Returns the number of entries |
| `isEmpty()` | Checks if the map is empty |
| `entrySet()` | Returns an iterable of all entries |
| `keySet()` | Returns an iterable of all keys |
| `values()` | Returns an iterable of all values |

# 5 - Priority Queues

### Priority queue implementations

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%201.png)

---

### Priority Queue Sorting Algorithms

1. **Selection Sort (Unsorted Sequence)**:
    - **Time Complexity**: `insert`: O(n), `remove_min`: O(n^2)
2. **Insertion Sort (Sorted Sequence)**:
    - **Time Complexity**: `insert`: O(n^2), `remove_min`: O(n)
3. **Heap-Sort** (Uses a min-heap for efficient sorting)
    - **Time Complexity**: `insert`, `remove_min`: O(logn)

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%202.png)

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%203.png)

---

### Heap Data Structure (Min-Heap)

1. **Properties**: (remember to explain both nodes and the root of the heap)
    
    ![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%204.png)
    
2. **Height**: O(logn).
3. **Min-Heap Operations**:
    
    
    | Operation | Description | Time  |
    | --- | --- | --- |
    | Build Heap | Builds a heap from an unsorted array | O(n) |
    | `insert` | Insert at the last position and perform **upheap** | O(log⁡n) |
    | `remove_min` | Replace the root with the last node, remove the last node, and perform **downheap** | O(log⁡n) |
    | Access root `min` | Returns the min/max element without removal | O(1) |
    | Decrease/Increase Key | Adjusts the value of a specific key | O(log⁡n) |
    | Find Next Last Node After Deletion | Start from the old last node, go up to find a right child or root, go to sibling, then down to leaf | O(logn) |

---

- **Counting Inversions with Selection Sort**:
    - **Inversions** are pairs (i,j) in an array A where i<j but A[i]>A[j].
    - By performing **Selection Sort** on an array, the **number of swaps** needed is equal to the **number of inversions** in the array. This is because each swap corrects one inversion, moving a larger element to its proper position relative to a smaller element that was previously after it.
- **Finding the k-th Value in Sorted Order Using Heaps**:
    - Given an unsorted array A, you can use a **min-heap** or **max-heap** to efficiently find the k-th smallest or largest element without fully sorting the array.
    - **Using a Min-Heap**:
        - A **min-heap** helps to track the smallest elements in the array.
        - The **root** of the min-heap is the smallest element.
        - To find the k-th largest element, keep only the k largest elements in the min-heap by replacing the root if a new element is larger. After inserting k elements, the root will be the k-th largest element.
    - **Using a Max-Heap**:
        - A **max-heap** works similarly but tracks the largest elements.
        - To find the k-th smallest element, maintain a max-heap of size k, where the root is the largest among the k smallest elements seen so far.
        - If a new element is smaller than the root, replace the root, ensuring the heap only keeps the smallest k elements. After processing all elements, the root will be the k-th smallest element.
- **Merging k Sorted Lists of Length m Using a Min-Heap**:
    - Given k sorted lists, each of length m, the goal is to merge them into a single sorted list efficiently.
    - **Method**:
        - Use a **min-heap** where each element in the heap represents the smallest unprocessed element from each of the k lists.
        - Inserting an element into the min-heap takes O(logk) time.
        - For k lists, inserting and removing elements from the heap will take O(klogk) time per element added to the result list.
    - **Overall Complexity**:
        - Since there are m elements in each of the k lists, the total number of elements to merge is km.
        - The time complexity for merging all elements is O(kmlogk), as each insertion and deletion operation on the min-heap takes O(logk) time.

### Heap Array Representation

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%205.png)

---

- **Counting Inversions with Selection Sort**:
    - the **number of swaps** needed is equal to the
        
        **number of inversions** in the array.
        
- **Finding the k-th Value in Sorted Order Using Heaps**:
    - keep only the k largest elements in the min-heap by
        
        replacing the root if a new element is larger. After 
        
        inserting k elements, the root will be the k-th largest element.
        
- **Merging k Sorted Lists of Length m Using a Min-Heap**:
    - For k lists, inserting and removing elements from the
        
        heap will take O(klogk) time per element added to the result list.                                       
        
        **Overall Complexity**: O(kmlogk)
        

# 6 - Hashing

### Key Concepts in Hash Tables

- **Load Factor (α)**: Defined as α=n/N (number of elements over table size). Ideally, α should be below 0.75 for optimal performance.

---

### Implementations of Map ADT

| Implementation | Description | Insert (put) | Search (get) | Delete (remove) | Space |
| --- | --- | --- | --- | --- | --- |
| **Simple List-Based Map** | Stores items in an unsorted list | O(1)(append) | O(n) | O(n) | O(n) |
| **Array-Based Map** | Uses an array for keys in a fixed range (e.g., [0, N-1]) | O(1） | O(1) | O(1) | O(N) (for fixed range N) |
| **Hash Table** | Maps keys to indices using a hash function | O(1) (average) | O(1)(average) | O(1)(average) | O(n) |

### Collision Handling

| Method | Description | Average Time Complexity | Suitable Scenarios |
| --- | --- | --- | --- |
| **Separate Chaining** | Each table cell points to a linked list that holds all items hashed to that index | O(1+α), worst-case O(n) | Allows higher load factors; requires extra memory for linked lists |
| **Linear Probing** | Places colliding items in the next available position (circularly) | O(1) with low load factor, worst-case O(n) (`get`, `put`, `remove`) | Efficient with careful load factor control, but may cause clustering |
| **Cuckoo Hashing** | Uses two hash tables and two hash functions | worse-case O(1) for `get`, `remove`, expected O(1) for `put` | Offers worst-case guarantees for lookups; more complex implementation |

### **Eviction Cycle Detection**:

1. **Use a Counter**:  to keep track of the number of evictions. If we evict enough times we are guaranteed to have a cycle.
2. **Flag Entries**: Keep an additional flag for each entry. Every time we evict an entry, we flag it. After a successful put, we need to unflag the entries flagged.

### Set Implementation Using a Map

- **Map-Based Set**: Use a map to store elements as keys, ignoring values.
- **Performance**: Using a hash-based map, primary set operations (add, remove, contains) typically have O(1) time complexity.

- **Using Hash Table with Doubly Linked List for `get`, `put`, `delete` in O(1) Time**:
    - By using a hash table in combination with a doubly linked list, we can perform `get`, `put`, and `delete` operations in constant time, O(1).
    - The doubly linked list maintains a pointer to the elements in the hash table, allowing for efficient insertion and deletion.
    - This approach is commonly used in data structures like **LRU (Least Recently Used) Cache**, where the hash table provides O(1) access to elements, and the doubly linked list maintains the order of elements for quick updates.
- **Finding the Most Frequent Value in O(n) Time**:
    - To find the most frequent element in a collection, a hash table can be used to count occurrences.
    - **Collision Handling**: To handle hash collisions, linear probing or chaining can be used.
    - After constructing the hash table, which stores the frequency of each element, traverse the hash table to identify the element with the highest frequency.
    - This approach runs in O(n) time because inserting and updating counts in the hash table takes O(1) on average per element, and scanning the hash table at the end also takes O(n).
- **Using `get()` in a Multimap with O(1+s) Time Complexity**:
    - A **multimap** allows multiple values to be associated with the same key.
    - By implementing a multimap with a hash table, we can retrieve all values associated with a key.
    - Since multiple values may be stored at the same hash address, using `get()` requires retrieving all values associated with that key.
    - The time complexity of `get()` is O(1+s), where s is the number of values associated with the key (i.e., the size of the list at that address). This includes the O(1) time to access the hash bucket and O(s) to retrieve all values.

# 7 - Graphs

## Graph Properties

**Tree:** A connected acyclic graph.

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%206.png)

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%207.png)

if Adjacency List need traverse, `removeVertex`: O(n+m) `removeEdge`: O(m)

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%208.png)

| Algorithm | Complexity (Adjacency List) | Edges |
| --- | --- | --- |
| **DFS** | O(n+m) | back edges |
| **BFS** | O(n+m) | cross edges |

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%209.png)

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2010.png)

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2011.png)

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2012.png)

### 2. Bipartite Check: **Using BFS to** color each node per layer.

- **Bipartite**: Adjacent nodes in different layers.

### 3. Cycle Detection

- **Using Adjacency List**: O(n)
    - Perform DFS to mark each node.
    - If you revisit a marked node, a cycle exists.
- **Using Adjacency Matrix**: O(n)
    - Perform DFS to mark nodes by rows and columns.
    - Check in-degrees and out-degrees to avoid getting stuck.

### 4. Identifying Cut Vertices and Cut Edges: O(n+m)

- **Cut Edges (Bridges)**:
    - In a DFS tree, for an edge (u,v) where u is the parent and v is the child:
        - If `down-and-up[v] > level(u)`, (u,v) is a cut edge.
        - If `down-and-up[v] ≤ level(u)`, (u,v) is not a cut edge.
- **Cut Vertices (Articulation Points)**:
    - The root of the DFS tree is a cut vertex if it has two or more children.
    - For any internal node u with two or more children, u is a cut vertex if
        
        and only if `down-and-up[v] ≥ level(u)` for any child v.
        

# 8 - Graph Algorithms

### 1. Dijkstra's Algorithm

- 

---

### 2. Shortest Path Problem with Vertex Costs

- Construct a new graph G′ based on the original graph G:
    - For each edge (u,v) in G, add an edge (u′,v′) in G′ with weight weight(u,v)+cost(v).
- **Binary Heap**:
    - Each insertion is O(logn).
- **Fibonacci Heap**:
    - Supports O(1) decrease key operations when edge weights are relaxed.

## Dijkstra’s Algorithm

Standard Heap: O(mlogn); Fibonacci Heap: O(m+nlogn); Binary Heap: O((m+n)logn)

- **Algorithm Overview**:
    - Initialize the starting node distance as 0, and all other nodes as infinity.
    - Update distances of adjacent nodes accordingly while expanding the shortest path.

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2013.png)

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2014.png)

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2015.png)

## Minimum Spanning Tree

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2016.png)

## Cycle-Cut Intersection

Claim. A cycle and a cutset intersect in an even number of edges.

### Prim's Algorithm

- **Steps**:
    1. Initialize the MST with an arbitrary vertex.
    2. Add the minimum-weight edge connecting the current tree to any vertex not in the tree.
    3. Repeat until all vertices are included in the MST.
- **Time Complexity**:
    - Binary heap: O(mlogn); Fibonacci heap: O(m+nlogn).

### Kruskal's Algorithm

- **Steps**:
    1. Sort all edges by weight.
    2. For each edge, check if it forms a cycle with the current MST using Union-Find.
    3. If no cycle is formed, add the edge to the MST.
    4. Stop once n−1 edges are added.
- **Time Complexity**:
    - Sorting edges: O(mlogm).
    - Using Union-Find to check cycles: O(n^2)
    - **`make_sets(A)`**: O(n) **`find(u)`**: O(1)  **`union(u, v)`**: O(n)

### Union-Find (in Kruskal's Algorithm to detect cycles)

- **Operations**:
    1. **make_sets**: Initializes singleton sets for each element.
    2. **find**: Finds the root representative of the set containing an element, with path compression to speed up future queries.
    3. **union**: Merges two sets, using union by rank to keep the tree shallow.
- **Time Complexity**:
    - **make_sets**: O(n).
    - **find**: O(α(n)) with path compression.
    - **union**: O(α(n)) with union by rank, where α(n) is the inverse Ackermann function (almost constant in practice).

## Prim's Algorithm

### Time Complexity

- **O(E log V)** using a heap
- **O(E + V log V)** using Fibonacci heap
    
    ![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2017.png)
    
    ![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2018.png)
    

## Kruskal's Algorithm

Kruskal's algorithm with a union find implementation 

### Time Complexity

O(ElogV) → **O(ElogE)**（因为在连通图中，E 最多为V^2，

所以 logE 和 logV 的数量级是相同的）。

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2019.png)

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2020.png)

### Shortest Path Problem with Edge Weights and Vertex Costs

- Create a new graph G′ by modifying each edge (u,v) in G.
- In G′, set the weight of (u′,v′) to **edge weight + cost of the destination vertex**.
- **Run Dijkstra’s Algorithm** on G′

### **Fibonacci Heap**:

- **Decrease Key Operation**: Triggered when an edge weight is relaxed, with complexity O(m)×O(1)=O(m).
- **Insertion on Vertices**: O(nlogn).
- **Total Complexity with Fibonacci Heap**: O(m+nlogn).

# 9 -Greedy Algorithms

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2021.png)

### Key Problems and Algorithms

| Problem | Greedy Choice | Complexity | Correctness |
| --- | --- | --- | --- |
| **Fractional Knapsack** | Maximize benefit within a weight constraint by taking fractions of items | O(nlog⁡n) for sorting, O(n) for processing | Optimal (exchange argument) |
| **Interval Partitioning** | Minimize the number of classrooms needed for lectures, ensuring no overlap in the same room. | O(nlog⁡n) using a priority queue | Optimal (uses priority queue) |
| **Huffman Encoding** | Combine lowest frequency characters | O(n+dlog⁡d), where d is the number of distinct characters | Optimal (builds minimum encoding tree) |

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2022.png)

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2023.png)

### Summary of Concepts

1. **Optimal Solution in an Algorithm**:
    - The algorithm always returns an **optimal solution**.
    - It does not always find the minimum difference between two values; instead, it finds the **minimum for each element**.
    - This ensures the overall minimum in the difference as well.
2. **Tree Construction with Frequencies f=2if = 2^if=2i**:
    - When given frequencies in the form f=2i, the algorithm constructs a tree where **every internal node has an external node**.
        
        f=2if = 2^i
        
    - The algorithm creates a new node and picks the smallest frequency, corresponding to the leaf (external node).
    - Every internal node will always have an external frequency 2i.
        
        2i2^i
        
3. **Determining Interval Length in a Set**:
    - To find the interval covering all points in a set, **sort** the points first.
    - For each point, check if it has been covered.
    - If not covered, start from that point and expand the interval to cover other points.
    - **Time Complexity**: O(nlogn) due to sorting.
4. **Optimal Job Scheduling**:
    - To get the optimal schedule, **sort jobs** by the ratio of **job weight to time**.
    - Compute the **ratio of job weight to time** for prioritization.
    - This returns the optimal schedule that maximizes the total weight.
    - **Time Complexity**: O(nlogn), as sorting is required.

# 10 - Divide and Conquer I

- **Divide**: If it’s a base case (like a problem of size 1), solve directly; otherwise, split the problem into sub-problems.
- **Recur/Delegate**: Recursively solve each sub-problem.
- **Conquer**: Combine the solutions of the sub-problems to form the overall solution.

### Complexity Analysis via Recurrence Relations

| Example Algorithm | Recurrence | Solution | Correctness |
| --- | --- | --- | --- |
| Array Binary Search | T(n)=T(n/2)+O(1) | O(log⁡n) | Invariant (x is in A) |
| Merge Sort | T(n)=2T(n/2)+O(n) | O(nlog⁡n) | Induction |
| Quick Sort | T(n)=T(nL)+T(nR)+O(n) | O(nlogn) on average |  |

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2024.png)

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2025.png)

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2026.png)

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2027.png)

## Proof by Unrolling - T(n)=2T(n/2) + O(n)

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2028.png)

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2029.png)

## Some recurrence formulas with solutions

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2030.png)

# 11 - Divide and Conquer II

### Maxima-Set (Pareto Frontier)

1. **Preprocessing**: Sort points by x-coordinate (and y-coordinate to break ties).
2. **Divide**: Split into two halves.
3. **Recur**: Find maxima for each half.
4. **Conquer**: Combine results by comparing points on the left to the highest point on the right.
- **Time Complexity**: O(nlogn) due to sorting and merging.
    
    ![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2031.png)
    

### Integer Multiplication

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2032.png)

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2033.png)

### Selection (Median of Medians)

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2034.png)

### Master Theorem

![image.png](COMP2123%20Review%20Notes%20130ae068480080f2ae3cf244db6b9a04/image%2035.png)